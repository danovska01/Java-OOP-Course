package telephony1;

public interface Callable {
    String call();
}
