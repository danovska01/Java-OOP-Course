package telephony1;

public interface Browsable {
    String browse();
}
