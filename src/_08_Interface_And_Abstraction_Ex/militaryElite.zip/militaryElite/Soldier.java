package militaryElite;

public interface Soldier {

    int getId();
    String getFirstName();
    String getLastName();
}
