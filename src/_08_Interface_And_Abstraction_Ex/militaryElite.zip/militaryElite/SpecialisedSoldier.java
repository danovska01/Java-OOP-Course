package militaryElite;

public interface SpecialisedSoldier extends Soldier{
    String getCorps();
}
