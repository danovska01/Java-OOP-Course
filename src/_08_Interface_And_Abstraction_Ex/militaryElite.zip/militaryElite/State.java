package militaryElite;

public enum State {
    IN_PROGRESS,
    FINISHED
}
