package militaryElite;

public enum Corps {
    AIRFORCES,
    MARINES
}
