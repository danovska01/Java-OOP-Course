package SayHello;

import java.io.Serializable;

interface Person extends Serializable {

       String getName();
      String sayHello();
}
