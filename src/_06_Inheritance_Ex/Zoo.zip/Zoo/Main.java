package Zoo;

public class Main {
    public static void main(String[] args) {
        Snake snake = new Snake("snake");
        System.out.println(snake.getName());
    }
}
