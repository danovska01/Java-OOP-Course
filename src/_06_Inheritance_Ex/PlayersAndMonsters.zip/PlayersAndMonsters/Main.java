package PlayersAndMonsters;

public class Main {
    public static void main(String[] args) {
        BladeKnight b = new BladeKnight("dd", 3);
        System.out.println(b);
        Hero h = new Hero("erer", 4);
        System.out.println(h);





    }
}
