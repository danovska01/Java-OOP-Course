package MathOperation;

public class MathOperation {
    public int add(int x1, int x2){
        return x1+x2;
    }
    public int add(int x1, int x2, int x3){
        return x1+x2+x3;
    }
    public int add(int x1, int x2, int x3, int x4){
        return x1+x2+x3+x4;
    }
}
